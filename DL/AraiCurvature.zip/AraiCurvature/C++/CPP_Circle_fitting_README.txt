C++ codes for determining the best-fit circle to X-Y data.
With thanks to N. Chernov for development of the code and permission to distribute it.

1) CircleFitByTaubin.cpp
Circle fitting routine of Taubin, G. (1991), Estimation of planar curves, surfaces, and nonplanar space curves defned by implicit equations with applications to edge and range image segmentation, IEEE Trans. Pattern Anal. Mach. Intell., 13, 1115-1138, doi:10.1109/34.103273.
To be used as initial guess for the least-square method below.

2) CircleFitByCL.cpp
Least-square method of Chernov, N., and C. Lesort (2005), Least squares fitting of circles, J. Math. Imaging Vision, 23, 239-252, doi:10.1007/s10851-005-0482-8.
Iterative least-squares routine that can robustly fit a circle to a small arc. This is essential for near linear Arai plots.
