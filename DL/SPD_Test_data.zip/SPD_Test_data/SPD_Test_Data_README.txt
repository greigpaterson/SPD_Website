ReadMe for for the SPD test data set

If any problems are encountered, or if you have comments or corrections, please contact Greig A. Paterson
greig.paterson "at" mail.iggcas.ac.cn


1) TT Format folder
Contains all of the test data in a format compatible with the ThellierTool software.

2) SPD_Anis_Tensors.dat
Tab delimited text file containing the 6 unique anisotropy tensor elements (s1 to s6) for the specimens that require correction for anisotropic TRM (m428b1, rs25b, rs26a, rs26e).

3) SPD_B_Lab.dat
Tab delimited text file containing the strength (|B_Lab| (muT)) and direction (B_Lab_x, B_Lab_y, and B_Lab_z) of the applied laboratory field for the test data.

4) SPD_NLT_factors.dat
Tab delimited text file containing the 2 coefficient (A1 and A2) for the hyperbolic tangent fit for specimens that require correction for non-linear TRM (rs25b, rs26a, rs26e).

5) SPD_Test_Data.thl
The Arai plot best-fits as output by the ThellierTool software.

6) SPD_Test_Data_MagIC.txt
Contains all of the test data in the MagIC_Measurement format compatible with the ThellierGUI software.

7)SPD_Test_Data_Table.xlsx
Excel formatted spread sheet that contains the details of the test data vest-fits and all of the SPD parameter (sheet "Statistics").



