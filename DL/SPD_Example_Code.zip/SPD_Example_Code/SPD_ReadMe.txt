ReadMe for SPD.m, the MATLAB function for obtaining paleointensity parameters.

If any problems are encountered, or if you have comments or corrections, please contact Greig A. Paterson
greig.paterson "at" mail.iggcas.ac.cn

%%%%%%%%%%%%%%%%%%%%%
%% Version History %%
%%%%%%%%%%%%%%%%%%%%%
NOTE: The version numbers of the code and SPD are not designed to coincide

Version C1.1 - 17 June, 2014
1) Added kprime introduced in SPD v1.1
2) Corrected an error in IZZI_MD, where all points were used to determine the line length, not just the ZI steps
3) Corrected typo in additivity check calculation that caused an error

Version C1.0 - 24 Feb, 2014
The first release of the SPD code (SPD v1.0)


%%%%%%%%%%%%%%%%
%% How to use %%
%%%%%%%%%%%%%%%%

1) Input
The SPD function can be call from MATLAB using the following:
[Params] = SPD(Mvec, Temps, Treatment, start_pt, end_pt, Blab_orient, Blab, NRM_rot_flag, Az, Pl, ChRM, A_corr, s_tensor, NLT_corr, NLT_hat, beta_T);

The inputs are:
Mvec			-	a (n x 3) matrix of magnetization values when n is the total number of steps, which includes NRM, TRM, and all check measurements (i.e., the raw data measurements)
Temps			-	a (n x 1) vector of the temperature of each treatment
Treatment		-	a (n x 1) vector of integer values describing the treatment type at each step, this follows the convention of the ThellierTool (0=NRM demag, 1=TRM remag, 2=pTRM check, 3=pTRM tail check, 4=additivity check, 5=inverse TRM step). If any Treatment is set to '5' all data are treated as a Thellier experiment
start_pt		-	the index of the temperature for the start point for the Arai plot best-fit line
end_pt			-	the index of the temperature for the end point for the Arai plot best-fit line
Blab_orient		-	a (1 x 3) unit vector containing the x, y, z values for a know Blab orientation.
Blab			-	the strength of the laboratory field in muT
NRM_rot_flag	-	flag for directional rotation from core coords to stratigraphic coords (0 or []=no rotation, 1=apply rotation)
Az				-	the core azimuth in degrees
Pl				-	the core plunge in degrees - angle from horizontal, positive down
ChRM			-	a (1 x 2) or a (1 x 3) vector describing an independent measure of the direction of Banc (can be a known direction).
					If ChRM is a (1 x 2) vector it is assumed to be a Dec/Inc direction and converted to a Cartesian vector.
					If rotation is applied ChRM is assumed to already be in the final coordinate system
A_corr			-	flag for anisotropy correction (0=no correction, 1=apply correction)
s_tensor		-	a (1 x 6) vector with the six unique elements that describe an anisotropy tensor
NLT_corr		-	flag for non-linear TRM correction (0=no correction, 1=apply correction)
NLT_hat			-	a (1 x 2) vector containing the coefficients of the best-fit hyperbolic tangent function
beta_T			-	a (1 x 1) scalar for the beta threshold for defining the SCAT box, if missing the default value is beta_T=0.1

Where an input is to be omitted, for example if no directional rotation is needed, then the inputs can be replaced by []. For examples:
[Params] = SPD(Mvec, Temps, Treatment, start_pt, end_pt, Blab_orient, Blab, 0, [], [], [], A_corr, s_tensor, NLT_corr, NLT_hat, beta_T);

A MATLAB mat file ("Example_Input_RS25b.mat") is given as an example for the input data. This is from specimen RS25b and uses the same input as used for the example SPD output.


2) Output
Output is a MATLAB structure with fields listed below. Use Params.Xpts to access Xpts, for example.
See the Standard Paleointensity Definitions for full details of the statistics.

Xpts			-	TRM points on the Arai plot
Ypts			-	NRM points on the Arai plot
N				-	number of points for the best-fit line on the Arai plot
nmax			-	the total number of NRM-TRM points on the Arai plot
Seg_Ends		-	the indices for the start and end of the best-fit line [2x1]
Hanc			-	the unit vector in the direction of Banc as calculated by Selkin et al. (2000; EPSL) for the correction of anisotropy
anis_scale		-	factor used to scale the TRM vectors to correct for the effects of anisotropy
b				-	the slope of the best-fit line
sigma_b			-	the standard error of the slope
beta			-	sigma_b/b
X_int			-	the intercept of the best-fit line of the TRM axis
Y_int			-	the intercept of the best-fit line of the NRM axis
Px				-	the Arai plot TRM points projected onto the best-fit line
Py				-	the Arai plot NRM points projected onto the best-fit line
VDS				-	the vector difference sum of the NRM vector
f				-	the fraction of NRM used for the best-fit line
f_vds			-	the NRM fraction normalized by the VDS
FRAC			-	the NRM fraction with full vector calculation (Shaar & Tauxe, 2013; G-Cubed)
gap				-	the gap factor
GAP_MAX			-	the maximum gap (Shaar & Tauxe, 2013; G-Cubed)
qual			-	the quality factor
w				-	the weighting factor of Prevot et al. (1985; JGR)
R_corr			-	Linear correlation coefficient (Pearson correlation)
R_det			-	Coefficient of determination of the SMA linear model fit
Line_Len		-	the length of the best-fit line
f_vds			-	the fraction of vector difference sum NRM used for the best-fit line
k				-	the curvature of the Arai plot following Paterson (Paterson, 2012; JGR)
SSE				-	the fit of the circle used to determine curvature (Paterson, 2012; JGR)
kprime			-	the curvature of the Arai plot using the best-fit segment, following Paterson (Paterson, 2012; JGR)

MAD_anc			-	the maximum angular deviation of the anchored PCA directional fit
MAD_free		-	the maximum angular deviation of the free-floating PCA directional fit
alpha			-	the angle between the anchored and free-floating PCA directional fits
alpha_prime		-	the angle between the anchored PCA directional fit and the true NRM direction (assumed to be well known)
DANG			-	the deviation angle (Tauxe & Staudigel, 2004; G-Cubed)
Theta			-	the angle between the applied field and the NRM direction (determined as a free-floating PCA fit to the TRM vector)
a95				-	the alpha95 of the Fisher mean of the NRM direction of the best-fit segment
NRM_dev			-	the intensity deviation of the free-floating principal component from the origin, normalized by Y_int (Tanaka & Kobayashi, 2003; EPS)
CRM_R			-	the potential CRM% as defined by Coe et al. (1984; JGR)

SCAT			-	SCAT parameters of Shaar & Tauxe (2013). N.B. the beta threshold is hard-wired to 0.1

Z				-	the zigzag parameter of Yu & Tauxe (2005; G-Cubed)
Z_star			-	the zigzag parameter of Yu (2012; JGR)
IZZI_MD			-	the zigzag parameter of Shaar et al. (2011, EPSL)

N_alt			-	the number of pTRM checks used to the maximum temperature of the best-fit segment
PCpoints		-	(N_alt x 3) array. First column is temperature the check is to (Ti), second is the temperature the check is from (Tj), third is total pTRM gained at each pTRM check (= pTRM_check_i,j in SPD)
check			-	the maximum pTRM difference when normalized by pTRM acquired at each check step
dCK				-	pTRM check normalized by the total TRM (i.e., X_int) (Leonhardt et al., 2004; G-Cubed)
DRAT			-	pTRM check normalized by the length of the best-fit line (Selkin & Tauxe, 2000; Phil Trans R Soc London)
maxDEV			-	maximum pTRM difference normalized by the length of the TRM segment used for the best-fit slope (Blanco et al., 2012; PEPI)
CDRAT			-	cumulative DRAT (Kissel & Laj, 2004; PEPI)
CDRAT_prime		-	cumulative absolute DRAT
DRATS			-	cumulative pTRM check normalized by the maximum pTRM of the best-fit line segment (REF - Tauxe...)
DRATS_prime		-	cumulative absolute pTRM check normalized by the maximum pTRM of the best-fit line segment
mean_DRAT		-	CDRAT divided by number of checks
mean_DRAT_prime	-	the average DRAT (Herro-Bervera & Valet, 2009; EPSL)
mean_DEV		-	average pTRM difference normalized by the length of the TRM segment used for the best-fit slope (Blanco et al., 2012; PEPI)
mean_DEV_prime	-	average absolute pTRM difference normalized by the length of the TRM segment used for the best-fit slope
dpal			-	cumulative check of Leonhardt et al. (2004; G-Cubed)

N_MD			-	the number of tail checks used to the maximum temperature of the best-fit segment
MDpoints		-	(N_MD x 2) array. First column is temperature, second is the remanence remaining after the demagnetization step for a pTRM tail check (= tail_check_i in SPD)
dTR				-	tail check normalized by the total NRM (i.e., Y_int) (Leonhardt et al., 2004; G-Cubed)
DRATtail		-	tail check normalized by the length of the best-fit line (Biggin et al., 2007; EPSL)
MDvd			-	tail check normalized by the vector difference sum corrected NRM (REF - Tauxe...)
dt_star			-	pTRM tail after correction for angular dependence (Leonhardt et al., 2004; G-Cubed)

N_AC			-	the number of additivity checks used to the maximum temperature of the best-fit segment
ADpoints		-	(N_AC x 3) array. First 2 columns are lower and upper temperatures for remaining pTRM, third is the remanence remaining after a repeat demagnetization additivity check (= Mrem in SPD)
d_AC			-	maximum additivity check normalized by the total TRM (i.e., X_int) (Leonhardt et al., 2004; G-Cubed)
